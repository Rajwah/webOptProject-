var markerLoaded = false;
//CUSTOM STYLE FOR MY MAP
 var styles = [
        {
          featureType: 'water',
          stylers:[
          {color: '#66ffff'}
          ]
        },{
          featureType: 'administrative',
          elementType: 'lables.text.stroke',
          stylers: [ 
          { color: '#6600cc'},
          {weight: 1 }
          ]

        },{
          featureType: 'road.highway',
          elementType: 'geometry.stroke',
          stylers:[
          {color:'#660033'},
          {lightness: -20}
          ]
        },{
          featureType: 'transit.station',
          stylers: [ 
          {weight: 9},
          {hue: '#0e85113'}
          ]
        }];
//array for my loations in the map including name and coordinates
var locations = [
	{name:"Chapters house", coordinates: { lat:44.63995349999999, lng:-63.579952700000035}},
	{name:"Dalhousie University", coordinates: { lat:44.63658119999999, lng: -63.5916555 }},
	{name:"Cienplex", coordinates: { lat:44.707778, lng:-63.56044399999996}},
	{name:"Public graden", coordinates: { lat:44.642761, lng:-63.582124}},
	{name:"TSmittys", coordinates: { lat:44.6416810, lng:-63.5806049}},
	{name:"Point pleasent park", coordinates: { lat:44.623255, lng:-63.568589}},
	{name:"The Bicycle Thief restaurant", coordinates: { lat:44.643625, lng:-63.568436}},
];


//the following are the list of places to be displayed in the side menue
var placesList = [
		   {name: 'Chapters house'},{name: 'Dalhousie University'},{name: 'Cienplex'},{name: 'Public graden'}, {name: 'Smittys'},{name: 'Point pleasent park'},{name: 'The Bicycle Thief restaurant'}];
var map;
var marker;
var markersList = {};
//initiolaizig google map
function initMap() {
	map = new google.maps.Map(document.getElementById('map'), {
		center: {lat: 44.666387, lng: -63.577023},
		zoom: 13,
		styles: styles,
		mapTypeControl: false
	});
	
	var infoWindow = new google.maps.InfoWindow();
	//this is the default style for marker 
     var defaultIcon =  makeMarkerIcon('0091ff');
//the color of the marker will change when you hover over it 
     var highlightedIcon =  makeMarkerIcon('FFFF24');
	// here we will start creating the markers on the map
var markerCreation= function(){
		marker = new google.maps.Marker({
			position: locations[j].coordinates,
			name: locations[j].name,
			map: map,
			animation: google.maps.Animation.DROP,
            icon: defaultIcon,
            id: j
		});
		var name = locations[j].name;
		markersList[name] = marker;
		addListenerToMarker(marker, name);
		colseInfoBox(marker);
	}
	var len= locations.length;
	for (var j = 0; j < len; j++) {
			markerCreation(locations[j]);
	}

	markerLoaded = true;
	//this function add listener to each marker 
	var finalContent;
	function addListenerToMarker(marker, name) {
		var infoBox = "<h1 id='placeName'>" + name + "</h1>";

		  marker.addListener('mouseover', function(){
        this.setIcon(highlightedIcon);
      });
      marker.addListener('mouseout', function(){
        this.setIcon(defaultIcon);
      });
		//opening the info windwo when click which include the name of the place 
		marker.addListener('click', function() {
				finalContent = infoBox;
				infoWindow.open(map, marker);
				infoWindow.setContent(finalContent);
			});
	}
 
	function colseInfoBox(marker) {
		infoWindow.addListener('closeclick', function() {
			marker.setAnimation(null);
		});
	}
}



function SelectedPlaces(item) {
	this.name = ko.observable(item.name);
	this.marker = ko.observable(item.marker);
};

// Knockout ViewModel
var ViewModel = function() {
	var self = this;
	//HERE we create array of loctions
	self.locationList = ko.observableArray([]);
	self.query = ko.observable('');

     //then we need to push a loactionn into this list 
	placesList.forEach(function(item) {
		self.locationList.push(new SelectedPlaces(item));
	});
//this function display the marker info 
	this.displayMarkerInfo = function(clikedLocation) {
		var spot = name.name();
		google.maps.event.trigger(markersArray[spot], 'click');
	};
	// Filter Function (includes Marker functions that are handled via Knockout's computed observable)
	this.filter = ko.observable("");
	// Computed observable from Knockout which filters out arrays and markers from the input
	this.filterSearch = ko.computed(function() {
		var filter = self.filter().toLowerCase();

	});
};



  function makeMarkerIcon(markerColor){
    var markerImage = new google.maps.MarkerImage(
      'http://chart.googleapis.com/chart?chst=d_map_spin&chld=1.15|0|'+ markerColor+ '|40|_|%E2%80%A2',
      new google.maps.Size(21, 34),
      new google.maps.Point(0, 0),
      new google.maps.Point(10, 34),
      new google.maps.Size(21, 34));
    return markerImage;
  }

  //this function work when we have errror in openeing the map
function googleError() {
    var myMap= document.getElementById('map');
    myMap.innerHTML = "<h6> Cann't download google map, Please refresh the page</h6>";
}
var stringStartsWith = function (string, startsWith) {
	string = string || "";
	if (startsWith.length > string.length) {
		return false;
	}
	return string.substring(0, startsWith.length) === startsWith;
};


var myViewModel = new ViewModel();
ko.applyBindings(myViewModel);